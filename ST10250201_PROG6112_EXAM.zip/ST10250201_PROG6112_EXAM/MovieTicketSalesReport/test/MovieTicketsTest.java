import org.junit.Test;
import static org.junit.Assert.*;

public class MovieTicketsTest {

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        // Arrange
        MovieTickets movieTickets = new MovieTickets();
        int[] napoleonSales = {3000, 1500, 1700}; // Sales data for Napoleon

        // Act
        int result = movieTickets.TotalMovieSales(napoleonSales);

        // Assert
        assertEquals("The total sales for Napoleon should be 6200.", 6200, result);
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Arrange
        MovieTickets movieTickets = new MovieTickets();
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300}; // Total sales for Napoleon and Oppenheimer

        // Act
        String result = movieTickets.TopMovie(movies, totalSales);

        // Assert
        assertEquals("The top performing movie should be Oppenheimer.", "Oppenheimer", result);
    }
}

