/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class MovieTicketSalesReport {

    public static void main(String[] args) {
        // Declare single-dimensional array for movie names
        String[] movies = {"Napoleon", "Oppenheimer"};
        
        // Declare two-dimensional array for ticket sales
        int[][] ticketSales = {
            {3000, 1500, 1700}, // Napoleon sales for Jan, Feb, Mar
            {3500, 1200, 1600}  // Oppenheimer sales for Jan, Feb, Mar
        };

        // Instantiate MovieTickets object
        MovieTickets movieTickets = new MovieTickets();
        
        // Display report header
        System.out.println("MOVIE TICKET SALES REPORT - 2024\n");

        // Display table header
        System.out.printf("%-15s %-10s %-10s %-10s\n", "", "JAN", "FEB", "MAR");
        System.out.println("---------------------------------------------------------");

        // Array to store total sales for each movie
        int[] totalSales = new int[movies.length];

        // Loop through the sales array to display each movie's sales and calculate totals
        for (int i = 0; i < movies.length; i++) {
            // Display movie name and monthly sales
            System.out.printf("%-15s %-10d %-10d %-10d\n", movies[i], ticketSales[i][0], ticketSales[i][1], ticketSales[i][2]);

            // Calculate total sales using the MovieTickets class
            totalSales[i] = movieTickets.TotalMovieSales(ticketSales[i]);
        }

        // Display the total sales for each movie
        System.out.println("\nTotal movie sales for Napoleon: " + totalSales[0]);
        System.out.println("Total movie sales for Oppenheimer: " + totalSales[1]);

        // Determine the top performing movie
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("\nTop performing movie: " + topMovie);
    }
}
