/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MovieTicketsTest {

    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTickets movieTickets = new MovieTickets();
        int numberOfTickets = 10;
        double ticketPrice = 20.0;

        double total = movieTickets.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);
        
        // Check if the total is calculated correctly
        assertEquals(228.0, total, "The total price with VAT should be 228.0");
    }

    @Test
    public void ValidationTests() {
        MovieTickets movieTickets = new MovieTickets();

        // Test invalid data
        MovieTicketData invalidData = new MovieTicketData("", -1, -5);
        assertFalse(movieTickets.ValidateData(invalidData), "Data should be invalid");

        // Test valid data
        MovieTicketData validData = new MovieTicketData("Napoleon", 10, 15);
        assertTrue(movieTickets.ValidateData(validData), "Data should be valid");
    }
}
