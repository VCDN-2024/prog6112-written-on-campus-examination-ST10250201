/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class MovieTickets implements IMovieTickets {

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        return numberOfTickets * ticketPrice * 1.14; // Apply VAT (14%)
    }

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        if (movieTicketData.getMovieName().isEmpty()) {
            return false; // Movie name cannot be empty
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            return false; // Ticket price must be greater than 0
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return false; // Number of tickets must be greater than 0
        }
        return true;
    }

    double CalculateTotalTicketPrice(int quantity, double price) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
